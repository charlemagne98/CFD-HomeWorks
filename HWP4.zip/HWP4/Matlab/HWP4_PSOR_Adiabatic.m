clc;
clear;
close all;
[T,iteration,RES]=PSOR_adiabatic(1,1,10,20,0.001,0.8,3)

function [T,it,res]=PSOR_adiabatic(a,b,nx,ny,RES,w,wall)

    res=100;
    it=0;
    dx=a./nx;
    dy=b./ny; 
    B=dx./dy;
    x=linspace(0,a,nx);
    y=linspace(0,b,ny);
    T=zeros(ny,nx);
     if wall==3 || wall==2
        T1=input('T up:  ');
        T2=input('T side:  ');
        T4=input('T down:  ');
        T(1,:)=T1;
        T(end,:)=T4;
        T(:,1)= T2;
        T(1,1)=(T1+T2)./2;
        T(end,1)=(T4+T2)./2;
        Told=T;
            while res>RES
                it=it+1;
                Told=w.*T+(1-w).*Told;
                for i = 2:ny-1
                    for j= 2:nx
                        if j~=nx
                            T(i,j)=(1./(2.*(1+B.^2))).*(T(i,j+1)+T(i,j-1)+(B.^2).*(T(i+1,j)+T(i-1,j)));
                        elseif j==nx
                            T(i,j)=T(i,j-1);
                        end
                    end
                end
                res= sum(sum(abs(T-Told)));
            end
                if wall==3
                Tplot=flip(T,2);
                T=Tplot;
                Tplot=flip(Tplot,1);
                plot= contourf(x,y,Tplot);
                colorbar;
                else
                    Tplot=flip(T,1);
                    plot= contourf(x,y,Tplot);
                    colorbar; 
                end
            elseif (wall==4) || (wall==1)
                T2=input('T left:  ');
                T3=input('T right:  ');
                T4=input('T up or down:  ');
                T(1,:)=T4;
                T(:,1)= T3;
                T(:,end)= T2;
                T(1,1)=(T3+T4)./2;
                T(1,end)=(T4+T2)./2;
                Told=T;
            while res>RES
                    it=it+1;
                    Told=w.*T+(1-w).*Told;
                    for i = 2:ny
                            for j= 2:nx-1
                                if i~= ny
                                    T(i,j)=(1./(2.*(1+B.^2))).*(T(i,j+1)+T(i,j-1)+(B.^2).*(T(i+1,j)+T(i-1,j)));
                                elseif i==ny
                                    T(i,j)=T(i-1,j);
                                end
                            end
                    end
                    res= sum(sum(abs(T-Told)));
            end
            if wall==4
                T=flip(T,2);
                Tplot=flip(T,1);
                plot= contourf(x,y,Tplot);
                colorbar;
            else
                Tplot=flip(T,2);
                T=flip(Tplot,1);
                plot= contourf(x,y,Tplot);
                colorbar;
            end
     end
end
