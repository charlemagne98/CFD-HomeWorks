clc;
clear;
close all;
[T,Time,RES]=FTBS(1,1,40,50,100,200,300,400,0.001,1,0.01,0.01)
function [unew,time,res]=FTBS(a,b,nx,ny,T1,T2,T3,T4,RES,alpha,beta,dt)
    res=inf;
    dx=a./nx;
    dy=b./ny; 
    B=dx./dy;
    it=0;
    x=linspace(0,a,nx);
    y=linspace(0,b,ny);
    uold=zeros(ny,nx);
    uold(1,:)=T1;
    uold(end,:)=T4;
    uold(:,end)= T2;
    uold(:,1)= T3;
    uold(1,1)=(T1+T3)./2;
    uold(1,end)=(T1+T2)./2;
    uold(end,1)=(T3+T4)./2;
    uold(end,end)=(T4+T2)./2;
    unew=uold;
    uold2=uold;
    dn= (beta.*dt)./(dx.^2);
    dn2=(beta.*dt)./(dy.^2);
    if (dn>0.25) || (dn2>0.25)
        disp('Convergency Error')
        return
    else
        for i = 2:ny-1
            for j= 2:nx-1
                unew(i,j)=(dn).*(uold(i+1,j)-2.*uold(i,j)+uold(i-1,j))+(dn2)*(uold(i,j-1)-2.*uold(i,j)+uold(i,j+1))+uold(i,j);
            end
        end
        uold=unew;
    end
    landa=(2.*alpha.*dt)./(dx.^2);
    gama=(2.*alpha.*dt)./(dy.^2);
    while res>RES
        it=it+1;
        for i = 2:ny-1
            for j= 2:nx-1
                unew(i,j)=(landa./(1+landa+gama)).*(uold(i+1,j)+uold(i-1,j))+(gama./(1+landa+gama)).*(uold(i,j+1)+uold(i,j-1))+((1-gama-landa)./(1+gama+landa)).*uold2(i,j);
            end
        end
        res= sum(sum(abs(uold-unew)));
        uold2=uold;
        uold=unew;
    end
    time= it.*dt;
    uplot=flip(unew);
    plot= contourf(x,y,uplot);
    title('Matlab');
    colorbar;
    figure(2)
    plot=pcolor(x,y,uplot)  ;
    colorbar;
    shading 'interp'
    title('Matlab')
end


















